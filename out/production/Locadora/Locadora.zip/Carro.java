public class Carro implements Comparable<Carro>{
    private final String placa;
    private final String marca;
    private final String cor;
    private final String modelo;
    private final int valor;
    private final boolean pode_alugar;

    public Carro(String placa, String marca, String cor, String modelo,
                 int valor, boolean pode_alugar){
        this.placa = placa;
        this.marca = marca;
        this.cor = cor;
        this.modelo = modelo;
        this.valor = valor;
        this.pode_alugar = pode_alugar;
    }
     public String getPlaca(){
        return placa;
     }
     public String getMarca(){
        return marca;
     }
     public String getCor(){
        return cor;
     }
     public String getModelo(){
        return modelo;
     }
     public int getValor(){
        return valor;
     }
     public boolean getPode_Alugar(){
        return pode_alugar;
    }
    @Override
    public int compareTo(Carro carro) {
        return this.valor - carro.valor;
    }
    @Override
    public String toString(){
        return String.format("%n%s: %s %n%s: %s %n%s: %s %n%s: %s %n%s %d%n",
                "Marca", marca, "Modelo", modelo, "Cor", cor, "Placa", placa,
                "Valor da diária: R$", valor);
    }
}
