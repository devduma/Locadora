import java.util.Arrays;
import java.util.Scanner;

public class TestLocadora {
    public static Integer NUMERO_CARROS = 10;

    public static void main(String[] args) {
        Carro[] carros = new Carro[NUMERO_CARROS];

        carros[0] = new Carro("abc-1234","Jipe", "branco", "Renegade", 500, false);
        carros[1] = new Carro("kgf-4523","Honda", "cinza", "City", 300, true);
        carros[2] = new Carro("plk-2158","Toyota", "verde", "Corolla", 800, true);
        carros[3] = new Carro("kzf-2473","Nissan", "vermelho", "Kicks", 450, false);
        carros[4] = new Carro("dcn-0606","Honda", "branco", "Fit", 600, true);
        carros[5] = new Carro("los-6783","Fiat", "preto", "Uno", 150, true);
        carros[6] = new Carro("smp-2709","Ford", "cinza", "KA", 120, true);

        try (Scanner ler = new Scanner(System.in)) {
            System.out.println("Complete o cadastro com 3 novos veículos");
            int i = 1;
            do {
                System.out.println();
                System.out.println("Informe o número de placa do carro " + i);
                String placa = ler.next();

                System.out.println("Informe a marca do carro");
                String marca = ler.next();

                System.out.println("Informe o modelo");
                String modelo = ler.next();

                System.out.println("Informe a cor");
                String cor = ler.next();

                System.out.println("Informe o valor da diária");
                int valor = ler.nextInt();

                carros[i + 6] = new Carro(placa, marca, cor, modelo, valor, true);

                i++;
            } while (i <= 3);
        }

        Arrays.sort(carros);

        System.out.println("FIFTY CARS\n\nConfira nossos modelos:");
        int numModelo = 1;
        for (Carro c:carros){
            if (c.getPode_Alugar()) {
                System.out.printf("%nModelo %d%nMarca: %s%nModelo: %s%nCor: %s%nPlaca: %s%n" +
                                "Valor da diária: R$ %d%n", numModelo++, c.getMarca(),
                        c.getModelo(), c.getCor(), c.getPlaca(), c.getValor());
            }
        }
    }
}
